const StarEl = document.querySelectorAll(".fa-star");
const emojiEl = document.querySelectorAll(".far");

StarEl.forEach((StarEl, index) => {
    StarEl.addEventListener("click", () => {
        updateRating(index);
    })
});

function updateRating(index) {
    StarEl.forEach((StarEl, idx) => {
        if(idx < index + 1)
        {
            StarEl.classList.add("active");
        }
        else{
            StarEl.classList.remove("active");
        }
    })

    
    emojiEl.forEach((emojiEl) => {
        emojiEl.style.transform = `translateX(-${index * 50}px)`;
    })
}

